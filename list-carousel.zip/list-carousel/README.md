# carousel
Basic carousel with customized jQuery plugin.

## Features
  * **Sliding type** : `type :(apnd/ lastToFirst/ hiddenAnchor)` , default is _apnd_.
  * **Sliding delay** : `delay : <interger in ms(micro seconds)>` ,default is _5000_ ms.
  * **autoplay** : `(true|false)`.
  * **navigation** : `(true|false)`. To show the pagaination at bottom of the slides.
  * **Auto Play Delay** : `playTime : <interger in ms(micro seconds)>` ,default is _5000_ ms.
